# WPRO ANTIVIRUS

Une app antivirus Android/iOS/web créée avec Flutter Web.
## Fonctionnalités :
- Scanner de fichiers malveillants
- Nettoyage des fichiers inutiles et doublons
- Optimisation de la RAM et batterie

### Pour l’utiliser sur Vercel ou GitHub Pages :
1. Hébergez le dossier sur votre dépôt GitHub
2. Liez-le à Vercel
3. Ajoutez ce fichier `vercel.json` pour éviter les erreurs 404